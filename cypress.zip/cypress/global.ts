export const URL = {
    BASE_URL:'http://localhost:4200/',
    STAGE_URL: '1234',
    PROD_URL: '12345'
}