class Helpers {

    public openUrl(url: string): Cypress.Chainable<Cypress.AUTWindow> {
        return cy.visit(url)
    }
}

export const helpers = new Helpers()